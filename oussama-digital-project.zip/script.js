document.getElementById("contactBtn").addEventListener("click", function () {
  document.getElementById("message").textContent =
    "شكراً لاهتمامك! هذه رسالة تفاعلية من نموذج Oussama Digital.";
});
