# Oussama Digital

مشروع Portfolio بسيط لعرض صفحة هبوط رقمية متجاوبة.

## التقنيات
- HTML5
- CSS3
- JavaScript

## الملفات
- `index.html` — هيكل الصفحة
- `style.css` — التصميم والاستجابة
- `script.js` — التفاعل
